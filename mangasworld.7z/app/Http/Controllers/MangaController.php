<?php

namespace App\Http\Controllers;

use Request;
use App\Models\Manga;
use App\Models\Dessinateur;
use App\Models\Genre;
use App\Models\Scenariste;
use Exception;
use Session;

class MangaController extends Controller
{
    /**
     * Affiche la liste de tous les mangas
     * @return Vue listesMangas
     */
    public function getMangas()
    {
        $erreur = Session::get('erreur');
        Session::forget('erreur');
        $mangas = Manga::all();
        return view('listeMangas', compact('mangas', 'erreur'));
    }
    
    /**
     * Affiche tous les Mangas d'un genre
     * @param int $idGenre
     * @return Vue listerMangas
     */
    public function getMangasGenre()
    {
        $erreur = "";
        $id_genre = Request::input('cbGenre');
        if($id_genre){
            $mangas = Manga::where('id_genre', $id_genre)->get();
            return view('listeMangas', compact('mangas', 'erreur'));
        }else{
            $erreur = "Il faut sélectionner un genre !";
            Session::put('erreur', $erreur);
            return redirect('listerGenres/'.$erreur);
        }
    }
    
    public function updateManga($id)
    {
        $erreur = Session::get('erreur');
        Session::forget('erreur');
        $manga = Manga::find($id);
        $genres = Genre::all();
        $dessinateurs = Dessinateur::all();
        $scenaristes = Scenariste::all();
        $titreVue = "Modification d'un Manga";
        return view('formManga', compact('manga', 'genres', 'dessinateurs', 'scenaristes', 'titreVue', 'erreur'));
    }
    
    public function validateManga()
    {
        $id_manga = Request::input('id_manga');
        $id_dessinateur = Request::input('cbDessinateur');
        $prix = Request::input('prix');
        $id_scenariste = Request::input('cbScenariste');
        $titre = Request::input('titre');
        $id_genre = Request::input('cbGenre');
        
        if (Request::hasFile('couverture')){
            $image = Request::file('couverture');
            $couverture = $image->getClientOriginalName();
            Request::file('couverture')->move(base_path() . '/public/images/', $couverture);
        }else{
            $couverture = Request::input('couvertureHidden');
        }
        if ($id_manga > 0){
            $manga = Manga::find($id_manga);
        }else{
            $manga = new Manga();
        }
        $manga->titre = $titre;
        $manga->couverture = $couverture;
        $manga->prix = $prix;
        $manga->id_dessinateur = $id_dessinateur;
        $manga->id_scenariste = $id_scenariste;
        $manga->id_genre = $id_genre;
        $manga->id_lecteur = 1;
        
        $erreur = "";
        try{
            $manga->save();
        } catch (Exception $ex) {
            $erreur = $ex->getMessage();
            Session::put('erreur', $erreur);
            if ($id_manga > 0){
                return redirect('/modifierManga/' .$id_manga);
            }else{
                return redirect('/ajouterManga/');
            }
        }
        
        return redirect('/listerMangas');
    }
    
    public function addManga()
    {
        $erreur = Session::get('erreur');
        Session::forget('erreur');
        $manga = new Manga();
        $genres = Genre::all();
        $dessinateurs = Dessinateur::All();
        $scenaristes = Scenariste::all();
        $titreVue = "Ajout d'un Manga";
        return view('formManga', compact('manga', 'genres', 'dessinateurs', 'scenaristes', 'titreVue', 'erreur'));
    }
    
    public function deleteManga($id)
    {
        $manga = Manga::find($id);
        $erreur = "";
        try{
            $manga->delete();
        } catch (Exception $ex) {
            $erreur = $ex->getMessage();
            Session::put('erreur', $erreur);
            return redirect('/listerMangas' .$id_manga);
        }       
        return redirect('/listerMangas');
    }
}
