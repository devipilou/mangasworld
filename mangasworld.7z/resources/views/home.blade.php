@extends('layouts.master')
@section('content')
<div>
    <h1 class="bvn"> Bienvenue sur Mangas World ! </h1>
</div>
@stop