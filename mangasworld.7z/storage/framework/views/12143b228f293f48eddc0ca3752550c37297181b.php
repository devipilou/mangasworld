<!doctype html>
<html lang="fr">
    <head>
        <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/mangas.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/bootstrap-themeS.css')); ?>" rel="stylesheet">

        <!-- Scripts -->

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    </head>
    <body class="body">
        <div class="container">
            <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-target">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar+ bvn"></span>
                        </button>
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Mangas World</a>
                    </div>                   
                    <div class="collapse navbar-collapse" id="navbar-collapse-target">
                        <ul class="nav navbar-nav">                           
                            <li><a href="<?php echo e(url('/listerMangas')); ?>" data-toggle="collapse" data-target=".navbar-collapse.in">Lister</a></li>
                            <li><a href="<?php echo e(url('/listerGenres')); ?>" data-toggle="collapse" data-target=".navbar-collapse.in">Mangas par genre</a></li>
                            <li><a href="<?php echo e(url('/ajouterManga')); ?>" data-toggle="collapse" data-target=".navbar-collapse.in">Ajouter</a></li>   
                        </ul>  
                        <ul class="nav navbar-nav navbar-right"> 
                            
                        </ul>                         
                    </div>
                </div><!--/.container-fluid -->
            </nav>
        </div> 
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <script src="<?php echo e(asset('assets/js/jquery-2.1.3.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.js')); ?>" defer></script>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\pilou\mangasworld\resources\views/layouts/master.blade.php ENDPATH**/ ?>