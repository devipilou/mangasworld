<?php if($erreur!= ""): ?>
<p>
    <div class="alert-danger" role="alert">
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <?php echo e($erreur); ?>

    </div>
        </p>
        <?php endif; ?><?php /**PATH C:\xampp\htdocs\pilou\mangasworld\resources\views/error.blade.php ENDPATH**/ ?>