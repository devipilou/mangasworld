<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url' =>'validerManga', 'files' => true]); ?>

<div class="col-md-12 well well-sm">
    <center><h1><?php echo e($titreVue); ?></h1></center>
    <div class="form-horizontal">    
        <div class="form-group">
            <input type="hidden" name="id_manga" value="<?php echo e($manga->id_manga); ?>"/>
            <label class="col-md-3 control-label">Titre : </label>
            <div class="col-md-3">
                <input type="text" name="titre" 
                    value="<?php echo e($manga->titre); ?>" class="form-control" required autofocus>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label">Genre : </label>
            <div class="col-md-3">
                <select class='form-control' name='cbGenre' required>
                    <OPTION VALUE=0>Sélectionner un genre</option>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        selected=""
                        <option  value="<?php echo e($genre->id_genre); ?>"
                            <?php if($genre->id_genre == $manga->id_genre): ?>
                                selected="selected"
                            <?php endif; ?>
                        > <?php echo e($genre->lib_genre); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label">Scenariste : </label>
            <div class="col-md-3">
                <select class='form-control' name='cbScenariste' required>  
                    <OPTION VALUE=0>Sélectionner un Scenariste</option>
                    <?php $__currentLoopData = $scenaristes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scenariste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        selected=""
                        <option value="<?php echo e($scenariste->id_scenariste); ?>"
                            <?php if($scenariste->id_scenariste == $manga->id_scenariste): ?>
                                selected="selected"
                            <?php endif; ?>
                        > <?php echo e($scenariste->nom_scenariste); ?> <?php echo e($scenariste->prenom_scenariste); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label">Dessinateur : </label>
            <div class="col-md-3">
                <select class='form-control' name='cbDessinateur' required>
                    <OPTION VALUE=0>Sélectionner un Dessinateur</option>
                    <?php $__currentLoopData = $dessinateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dessinateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        selected=""
                        <option value="<?php echo e($dessinateur->id_dessinateur); ?>"
                            <?php if($dessinateur->id_dessinateur == $manga->id_dessinateur): ?>
                                selected="selected"
                            <?php endif; ?>
                        > <?php echo e($dessinateur->nom_dessinateur); ?> <?php echo e($dessinateur->prenom_dessinateur); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>     
        <div class="form-group">
            <label class="col-md-3 control-label">Prix : </label>
            <div class="col-md-3">
                <input type="text" name="prix" value="<?php echo e($manga->prix); ?>" class="form-control"  required>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label">Couverture : </label>
            <div class="col-md-6">
                <input type="hidden" name="MAX_FILE_SIZE" value="204800"/>
                <input name="couverture" type="file" class="btn btn-default pull-left"/>
                <input type="hidden" name="couvertureHidden" value="<?php echo e($manga->couverture); ?>"/>                
                <img src='<?php echo e(URL::to('/')); ?>/images/<?php echo e($manga->couverture); ?>' class='img-responsive pull-right imgReduite' 
                     alt='<?php echo e($manga->couverture); ?>' />
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
                <button type="submit" class="btn btn-default btn-primary">
                    <span class="glyphicon glyphicon-ok"></span> Valider
                </button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary" 
                    onclick="javascript: window.location = '<?php echo e(url('/')); ?>';">
                    <span class="glyphicon glyphicon-remove"></span> Annuler
                </button>
            </div>           
        </div>
        <?php echo Form::close(); ?>

        <div class="col-md-6 col-md-offset-3">
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pilou\mangasworld\resources\views/formManga.blade.php ENDPATH**/ ?>