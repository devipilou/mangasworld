<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="blanc">
        <h1>Liste de mes Mangas</h1>
    </div>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Titre</th>
                <th>Genre</th>
                <th>Dessinateur</th>
                <th>Scénariste</th>
                <th>Prix</th>
                <th style="width: 50px;">Modifier</th>
                <th style="width: 50px;">Supprimer</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $mangas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>   
            <td> <?php echo e($manga->titre); ?> </td>
            <td> <?php echo e($manga->genre->lib_genre); ?> </td>
            <td> <?php echo e($manga->dessinateur->nom_dessinateur); ?></td>
            <td> <?php echo e($manga->scenariste->nom_scenariste); ?> </td>
            <td> <?php echo e($manga->prix); ?> </td>         
            <td style="text-align:center;"><a href="<?php echo e(url('/modifierManga')); ?>/<?php echo e($manga->id_manga); ?>">
                <span class="glyphicon glyphicon-pencil" data-toggle="tooltip" data-placement="top" title="Modifier"></span></a>
            </td>
            <td style="text-align:center;">
                <a class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="Supprimer" href="#"
                    onclick="javascript:if (confirm('Suppression confirmée ?'))
                        { window.location='<?php echo e(url('/supprimerManga')); ?>/<?php echo e($manga->id_manga); ?>';}">
                </a>
            </td>            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <BR> <BR>
    </table>
    <div class="col-md-6 col-md-offset-3">
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pilou\mangasworld\resources\views/listeMangas.blade.php ENDPATH**/ ?>