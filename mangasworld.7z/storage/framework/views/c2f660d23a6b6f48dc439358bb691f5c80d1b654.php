<?php $__env->startSection('content'); ?>
<div>
    <h1 class="bvn"> Bienvenue sur Mangas World ! </h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pilou\mangasworld\resources\views/home.blade.php ENDPATH**/ ?>